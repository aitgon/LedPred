# LedPred 0.99.5

July 20, 2015

## Release Notes

- Some bug fixes

## Bug fixes

- One shot LedPred did not save model

