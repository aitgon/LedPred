library(testthat)
library(LedPred)

test_check("LedPred")
